package com.whatsapp.chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatsAppChatBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
